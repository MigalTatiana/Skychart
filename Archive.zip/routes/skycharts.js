const express = require('express');
const router = express.Router();
const pool = require('../db');
const upload = require('../middleware/upload');

router.post('/skycharts', upload.single('image'), async (req, res) => {
    const client = await pool.connect();
    
    try {
        await client.query('BEGIN');
        
        const { title, is_public, points } = req.body;
        const userId = req.user.id;
        const skychartQuery = `
            INSERT INTO skycharts (title, user_id, is_public, image_url) 
            VALUES ($1, $2, $3, $4) 
            RETURNING id
        `;
        
        const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;
        const skychartResult = await client.query(skychartQuery, [
            title, 
            userId, 
            is_public === 'true', 
            imageUrl
        ]);
        
        const skychartId = skychartResult.rows[0].id;
        
        const pointsData = JSON.parse(points);
        const pointQuery = `
            INSERT INTO skychart_points (skychart_id, x, y, radius, name) 
            VALUES ($1, $2, $3, $4, $5)
        `;
        
        for (const point of pointsData) {
            await client.query(pointQuery, [
                skychartId,
                point.x,
                point.y,
                point.radius,
                point.name
            ]);
        }
        
        await client.query('COMMIT');
        
        res.json({
            success: true,
            skychartId: skychartId,
            message: 'Скайчарт успешно создан'
        });
        
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Error saving skychart:', error);
        res.status(500).json({
            success: false,
            message: 'Ошибка при сохранении скайчарта'
        });
    } finally {
        client.release();
    }
});